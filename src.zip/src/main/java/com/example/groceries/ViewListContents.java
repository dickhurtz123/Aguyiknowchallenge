package com.example.groceries;

import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class ViewListContents extends AppCompatActivity {

    DatabaseHelper myDB;
    ArrayList<MyHandler> theList;
    ListView listView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.viewitems);

        listView = (ListView)findViewById(R.id.listView);
        myDB = new DatabaseHelper(this);

        display();
    }

    public void display(){

        theList=new ArrayList<MyHandler>();
        Cursor data = myDB.getListContents();
        if(data.getCount() == 0){
            Toast.makeText(ViewListContents.this, "Failed.",Toast.LENGTH_LONG).show();
        }
        else{
            while(data.moveToNext()){
                theList.add(new MyHandler(data.getString(1),data.getInt(2),data.getString(3),data.getInt(0)));

            }
            MyAdapter adapter=new MyAdapter(this,R.layout.row,theList);
            listView.setAdapter(adapter);
            registerForContextMenu(listView);
        }
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        menu.add(0,v.getId(),0,"Delete");
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info=(AdapterView.AdapterContextMenuInfo)item.getMenuInfo();
        int pos=info.position;
        if(item.getTitle()=="Delete"){
            if(myDB.deleteItem(theList.get(pos))) {
                Toast.makeText(getApplicationContext(), "Item deleted successfully", Toast.LENGTH_LONG).show();
                display();
            }
            else
                Toast.makeText(getApplicationContext(),"An error occurred while trying to delete the item",Toast.LENGTH_LONG).show();

        }
        return true;
    }
}

