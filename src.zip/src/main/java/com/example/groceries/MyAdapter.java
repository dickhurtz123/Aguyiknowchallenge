package com.example.groceries;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class MyAdapter extends ArrayAdapter {

    ArrayList<MyHandler> theList;

    public MyAdapter(Context context, int resource, ArrayList<MyHandler> theList) {
        super(context, resource, theList);
        this.theList=theList;
    }

    @Override
    public View getView(int position,View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater)getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View row = inflater.inflate(R.layout.row,parent,false);

        TextView name,quantity,note;
        name=(TextView)row.findViewById(R.id.textView1);
        quantity=(TextView)row.findViewById(R.id.textView2);
        note=(TextView)row.findViewById(R.id.textView3);

        name.setText(theList.get(position).getItemname());
        quantity.setText(""+theList.get(position).getQuantity());
        note.setText(theList.get(position).getNote());
        return row;
    }
}
