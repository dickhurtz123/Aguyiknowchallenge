package com.example.groceries;

public class MyHandler {
    String itemname;
    int quantity;
    String note;
    int id = 0;

    public MyHandler(String itemname, int quantity, String note, int id ) {
        this.itemname = itemname;
        this.quantity = quantity;
        this.note = note;
        this.id=id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getItemname() {
        return itemname;
    }

    public void setItemname(String itemname) {
        this.itemname = itemname;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }
}
