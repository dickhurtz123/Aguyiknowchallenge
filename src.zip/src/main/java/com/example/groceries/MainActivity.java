package com.example.groceries;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    DatabaseHelper myDB;
    Button addBtn, vlBtn;
    EditText edtText1, edtText2, edtText3;
    MyHandler handler;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtText1 = (EditText)findViewById(R.id.editText);
        edtText2 = (EditText)findViewById(R.id.editText2);
        edtText3 = (EditText)findViewById(R.id.editText3);
        addBtn = (Button)findViewById(R.id.button);
        vlBtn = (Button)findViewById(R.id.button1);
        myDB = new DatabaseHelper(this);


        vlBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,ViewListContents.class);
                startActivity(intent);

            }
        });


        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            String newEntry = edtText1.getText().toString();
            int newEntry2 = Integer.parseInt(edtText2.getText().toString());
            String newEntry3 = edtText3.getText().toString();

            if(edtText1.length() !=0 && edtText2.length() !=0 && edtText3.length() !=0){
                addData(newEntry, newEntry2, newEntry3);
                edtText1.setText("");
                edtText2.setText("");
                edtText3.setText("");
            }
            else{
                Toast.makeText(MainActivity.this, "You must put something in the text field",Toast.LENGTH_LONG).show();
            }
            }
        });

        }
        public void addData(String newEntry, int newEntry2, String newEntry3){
            boolean insertData = myDB.addData(newEntry, newEntry2, newEntry3);

            if(insertData == true){
                Toast.makeText(MainActivity.this, "Successfully Added.",Toast.LENGTH_LONG).show();
            }
            else{
                Toast.makeText(MainActivity.this, "Failed.",Toast.LENGTH_LONG).show();
            }
        }


    }
